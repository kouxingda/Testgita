package com.gupaoedu.vip.netty.rpc.api;

public interface IRpcHelloService {
    String hello(String name);
}
